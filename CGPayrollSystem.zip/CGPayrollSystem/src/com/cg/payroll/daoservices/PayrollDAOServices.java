package com.cg.payroll.daoservices;
import com.cg.payroll.beans.Associate;
public interface PayrollDAOServices {
	int save(Associate associate) ;
	boolean update(Associate associate);
	boolean delete(int associateId);
	Associate findById(int associateId);
	Associate [] findAll();
}