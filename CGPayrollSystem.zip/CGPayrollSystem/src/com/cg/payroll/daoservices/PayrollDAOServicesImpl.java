package com.cg.payroll.daoservices;

import com.cg.payroll.beans.Associate;

public class PayrollDAOServicesImpl implements PayrollDAOServices{

	@Override
	public int save(Associate associate) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public boolean update(Associate associate) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean delete(int associateId) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public Associate findById(int associateId) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Associate[] findAll() {
		// TODO Auto-generated method stub
		return null;
	}

}
