package com.cg.payroll.main;
import com.cg.payroll.beans.Associate;
import com.cg.payroll.beans.BankDetails;
import com.cg.payroll.beans.Salary;
public class MainClass {
	public static void main(String[] args) {
		
		Associate associate = new Associate(102, 15000, "Satish", "Mahajan", "ADM", "SR Con.", "JDJD283JD", "satish@capgemini.com", new BankDetails(11111, "HDFC", "hdfc122"), new Salary(15000, 1000, 1000));

		System.out.println(associate.getBankDetails().getIfscCode());
		
	
	}
}