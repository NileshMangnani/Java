package com.cg.mobile.main;

import com.cg.mobile.beans.Address;
import com.cg.mobile.beans.Bill;
import com.cg.mobile.beans.Customer;
import com.cg.mobile.beans.Plan;
import com.cg.mobile.beans.PostPaidAccount;

public class MainClass {

	public static void main(String[] args) {
		 Bill [] bills = new Bill [2];
		 bills [0] = new Bill(256, 558, 741, 742, 475);
		 bills [1] = new Bill(25, 58, 41, 42, 45);
		 Plan plan = new Plan(2568, 578, 44, 47, 21, 123, "hyd", "prime");
		 PostPaidAccount [] postPaidAccounts = new PostPaidAccount[2];
		 postPaidAccounts [0]= new PostPaidAccount("754756", plan, bills[0]);
		 postPaidAccounts [1]= new PostPaidAccount("751756", plan, bills[1]);
		 Address address =  new Address("hyd", "hyd", "5895", "india");
		 Customer customer = new Customer(254, "gayathri", "mavilla", "789456122", "gaythi@capgemini.com","55656565" , "45666", "10/08/96"	, address, postPaidAccounts[0]);
		 

		 System.out.println(customer.getPostPaidAccount().getBills().getNoOfLocalSMS());
		 
		 
		 
		 

		 
		 

	}

}
