package com.cg.payroll.main;

import com.cg.payroll.beans.Associate;
import com.cg.payroll.beans.BankDetails;
import com.cg.payroll.beans.Salary;

public class MainClass {

	public static void main(String[] args) {
		/* Associate associate = new Associate(102, 15000, "Gayathri", "Mavilla", "JAVA", "Engineer", "KJSIJDIJI", "gayathri@capgemini.com");
		 System.out.println(associate.getAssociateID()+" "+associate.getFirstName()+" "+associate.getLastName());
		 
	  BankDetails bank = new BankDetails(1565665688, "HDFC", "HDFC0527");
		 System.out.println(bank.getAccountNumber()+" " +bank.getBankName());
		 
		 Salary sal = new Salary(125, 4524, 14214, 458, 789, 258, 75, 456, 782, 14863.25, 7500.89);
		 System.out.println(sal.getBasicSalary());
		 */
		   
		 
	 /*Associate [] associates= new Associate[3]; //Associate array object  is created.
	 associates[0]=new Associate(102, 15000, "Gayathri", "Mavilla", "JAVA", "Engineer", "KJSIJDIJI", "gayathri@capgemini.com");
	 associates[1]=new Associate(115, 18000, "Gaya3", "Mavil", "JAVA", "Engineer", "KJSIJDGJI", "gayathri.c.m@capgemini.com");
	 associates[2]=new Associate(125, 18000, "Gaya3", "Mavil", "JAVA", "Engineer", "KJSIJDGJI", "gayathri.c.m@capgemini.com");

	 /*for (int i=0;i<associates.length;i++)
		System.out.println(associates[i].getAssociateID()+""+associates[i].getFirstName()+""+associates[i].getLastName()); */
	 
	/* for (Associate associate : associates) 
		 if(associate!=null&&associate.getAssociateID()==125)
		 {
			 System.out.println(associate.getAssociateID()+" "+associate.getFirstName());
		 }
	 */
		Associate associate = new Associate(102, 789, "Gayathri", "Mavilla", "Engineer", "Java", "KDHDUD", "gayathri@capgemini.com", new BankDetails(155668, "HDFC", "HDFC908"), new Salary(125, 258, 2568, 23568, 356, 36, 3636, 3636, 3663, 366.23, 52.25));
		
		System.out.println(associate.getBankDetails().getIfscCode());
		
	}
		 
}
	

